import cv2
import numpy as np

# read input image
ob = "ghe_new"
img = cv2.imread(f'tests/{ob}.png')
h, w, d = img.shape

div = 2
re = cv2.resize(img, (int(w/div), int(h/div)), interpolation = cv2.INTER_LINEAR)
print(re.shape)
cv2.imwrite(f"tests/{ob}_resize.png",re)

# hsv = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# # define range of blue color in HSV
# lower_yellow = np.array([10])
# upper_yellow = np.array([252])

# # Create a mask. Threshold the HSV image to get only yellow colors
# mask = cv2.inRange(hsv, lower_yellow, upper_yellow)

# # Bitwise-AND mask and original image
# result = cv2.bitwise_and(img,img, mask= mask)
# print(result.shape)
# cv2.imwrite("tests/mask_chair.png",result)
# # display the mask and masked image
# cv2.imshow('Mask',mask)
# cv2.waitKey(0)
# cv2.imshow('Masked Image',result)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

# $ fpie-gui -s chair_resize.png -t sofa.png -o result.jpg -n 10000